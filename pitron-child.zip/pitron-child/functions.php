<?php
add_action( 'wp_enqueue_scripts', 'pitron_child_enqueue_styles', 99 );

function pitron_child_enqueue_styles() {
   wp_enqueue_style( 'parent-style', get_stylesheet_directory_uri() . '/style.css' );
}

?>