<!-- /*
Template Name: Pricing Template 
*/ -->

<?php get_header(); ?>

<?php get_template_part('templates/parts/breadcrumb'); ?>

<!--Pricing Section -->

<?php get_template_part('templates/parts/prices'); ?>

<?php get_footer(); ?>