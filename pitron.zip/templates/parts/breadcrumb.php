<!-- Breadcrumb Area  -->

<div class="breadcroumb-area">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="breadcroumb-title">
					<h1><?php the_title(); ?></h1>
					<h6><a href="<?php echo home_url(); ?>">Home</a> / <?php the_title(); ?></h6>
				</div>
			</div>
		</div>
	</div>
</div>