<div class="process-area gray-bg section-padding pb-50">
		<div class="container">
			<div class="row">
				<div class="offset-lg-2 col-lg-8 text-center">
					<div class="section-title">
						<h6>Our Process</h6>
						<h2>How Do We <b>Works</b></h2>
					</div>
				</div>
			</div>
			<div class="row process-item-wrap">
				<div class="col-lg-3 col-md-6 col-12 wow fadeInLeft" data-wow-delay=".2s">
					<div class="single-process-item mb-50">
						<div class="process-num">
							<p>01</p>
						</div>
						<div class="process-icon">
							<img src="<?php echo get_theme_mod('step_1_icon'); ?>" alt="">
						</div>
						<div class="process-content">
						<h5><?php echo get_theme_mod('step_1_title'); ?></h5>
							<p><?php echo get_theme_mod('step_1_short_description'); ?></p>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6 col-12 wow fadeInLeft" data-wow-delay=".4s">
					<div class="single-process-item mb-50">
						<div class="process-num">
							<p>02</p>
						</div>
						<div class="process-icon">
							<img src="<?php echo get_theme_mod('step_2_icon'); ?>" alt="">
						</div>
						<div class="process-content">
						<h5><?php echo get_theme_mod('step_2_title'); ?></h5>
							<p><?php echo get_theme_mod('step_2_short_description'); ?></p>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6 col-12 wow fadeInLeft" data-wow-delay=".6s">
					<div class="single-process-item mb-50">
						<div class="process-num">
							<p>03</p>
						</div>
						<div class="process-icon">
							<img src="<?php echo get_theme_mod('step_3_icon'); ?>" alt="">
						</div>
						<div class="process-content">
						<h5><?php echo get_theme_mod('step_3_title'); ?></h5>
							<p><?php echo get_theme_mod('step_3_short_description'); ?></p>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6 col-12 wow fadeInLeft" data-wow-delay=".8s">
					<div class="single-process-item mb-50">
						<div class="process-num">
							<p>04</p>
						</div>
						<div class="process-icon">
							<img src="<?php echo get_theme_mod('step_4_icon'); ?>" alt="">
						</div>
						<div class="process-content">
							<h5><?php echo get_theme_mod('step_4_title'); ?></h5>
							<p><?php echo get_theme_mod('step_4_short_description'); ?></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>